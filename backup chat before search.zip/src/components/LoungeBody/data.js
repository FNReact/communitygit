const data = [
	{
		"id":  1,
		"image":  "https://images.pexels.com/photos/13301571/pexels-photo-13301571.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
		"title":  "Lorem Ipsum",
	},
	{
		"id":  2,
		"image":  "https://images.pexels.com/photos/14437077/pexels-photo-14437077.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
		"title":  "Lorem Ipsum",
	},
	{
		"id":  3,
		"image":  "https://images.pexels.com/photos/14353079/pexels-photo-14353079.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
		"title":  "Lorem Ipsum",
	},
	{
		"id":  4,
		"image":  "https://images.pexels.com/photos/14218611/pexels-photo-14218611.jpeg?auto=compress&cs=tinysrgb&w=1600&lazy=load",
		"title":  "Lorem Ipsum",
	}
]

export default data;