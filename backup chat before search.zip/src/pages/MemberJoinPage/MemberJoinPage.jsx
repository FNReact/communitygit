import React from 'react'

const MemberJoinPage = () => {
  return (
    <div>index</div>
  )
}

export default MemberJoinPage