export const GoogleApiKey = 'AIzaSyD4mdf6nDkpbLo6ToEFm3Tx3aAIjEWwjIQ&libraries';
